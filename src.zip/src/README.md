A chrome extension that searches Bandcamp for what you are currently listening to on SoundCloud.

Made by Michael Claus
